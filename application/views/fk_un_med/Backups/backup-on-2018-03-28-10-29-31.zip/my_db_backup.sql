#
# TABLE STRUCTURE FOR: articulos
#

DROP TABLE IF EXISTS `articulos`;

CREATE TABLE `articulos` (
  `id_articulo` int(11) NOT NULL AUTO_INCREMENT,
  `num_articulo` varchar(50) NOT NULL,
  `codigo_jde` int(40) NOT NULL,
  `fk_codigo_familia` int(11) NOT NULL,
  `fk_codigo_cat1` int(11) NOT NULL,
  `fk_codigo_cat2` int(11) NOT NULL,
  `fk_codigo_cat3` int(11) DEFAULT NULL,
  `descripcion1` char(255) NOT NULL,
  `descripcion2` char(255) NOT NULL,
  `texto_busqueda` varchar(60) NOT NULL,
  `tipo_linea` varchar(1) NOT NULL,
  `tipo_almacenamiento` varchar(1) NOT NULL,
  `id_un_med1` int(2) NOT NULL,
  `id_un_med2` int(2) NOT NULL,
  `pto_venta` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_articulo`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `articulos` (`id_articulo`, `num_articulo`, `codigo_jde`, `fk_codigo_familia`, `fk_codigo_cat1`, `fk_codigo_cat2`, `fk_codigo_cat3`, `descripcion1`, `descripcion2`, `texto_busqueda`, `tipo_linea`, `tipo_almacenamiento`, `id_un_med1`, `id_un_med2`, `pto_venta`, `status`) VALUES ('1', '22222225', '22222225', '1', '2', '3', NULL, 'articulo de prueba', 'articulo de prueba', 'articulo de prueba', 'S', 'P', '2', '2', '99', '1');


#
# TABLE STRUCTURE FOR: articulos_x_vale
#

DROP TABLE IF EXISTS `articulos_x_vale`;

CREATE TABLE `articulos_x_vale` (
  `id_vale_articulos` int(11) NOT NULL,
  `id_articulo_por_vale` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estado_entrega_item` int(11) NOT NULL,
  `cantidad_entregada` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `articulos_x_vale` (`id_vale_articulos`, `id_articulo_por_vale`, `cantidad`, `estado_entrega_item`, `cantidad_entregada`) VALUES ('1', '1', '12', '1', '0');


#
# TABLE STRUCTURE FOR: email_queue
#

DROP TABLE IF EXISTS `email_queue`;

CREATE TABLE `email_queue` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `to` varchar(255) NOT NULL,
  `cc` varchar(255) DEFAULT NULL,
  `bcc` varchar(255) DEFAULT NULL,
  `message` text NOT NULL,
  `status` enum('pending','sending','sent','failed') DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `headers` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=81 DEFAULT CHARSET=utf8;

INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('53', 'admin@admin.com', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #136. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Admin, Admin</p><br>\r\n    <p>Sector Aprobador:SELECCIÓN</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>4037</th>\r\n                   <th>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined index: descripcion</p>\n<p>Filename: email/new.php</p>\n<p>Line Number: 37</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\new.php<br />\n			Line: 37<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 80<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div></th>\r\n                   <th>222</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/136\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-20 16:18:44', '[Sistema de Vales #136]Nuevo Vale de Consumo #136');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('47', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #53] Su vale ya esta listo para ser retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> hola!!!!!!!!!!!!!!!!!!</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 02/05/2018 14:46:21</p>\r\n  <p>Su vale de consumo puede ser pasado a retirar por Pañol. <br> <strong>Detalle de Articulos a Entregar</strong><table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Código Articulo</th>\r\n                  <th>Descripción 1</th>\r\n                  <th>Cantidad Solicitada</th>\r\n                  <th>Cantidad a Entregar</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                \r\n                    <tr>\r\n                       <th>1</th>\r\n                       <th>Item de Prueba 1</th>\r\n                       <th>1</th>\r\n                       <th>0</th>\r\n                    <tr></tbody>\r\n                                </table></p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:18:40', '[Sistema de Vales #53] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('48', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #49] Su vale ya esta listo para ser retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> faltan los ganchos nada mas.</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 02/05/2018 13:39:40</p>\r\n  <p>Su vale de consumo puede ser pasado a retirar por Pañol. <br> <strong>Detalle de Articulos a Entregar</strong><table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Código Articulo</th>\r\n                  <th>Descripción 1</th>\r\n                  <th>Cantidad Solicitada</th>\r\n                  <th>Cantidad a Entregar</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                \r\n                    <tr>\r\n                       <th>1</th>\r\n                       <th>Item de Prueba 1</th>\r\n                       <th>1</th>\r\n                       <th>0</th>\r\n                    <tr>\r\n                    <tr>\r\n                       <th>4</th>\r\n                       <th>Articulo de Prueba 4</th>\r\n                       <th>2</th>\r\n                       <th>0</th>\r\n                    <tr></tbody>\r\n                                </table></p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:20:17', '[Sistema de Vales #49] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('49', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #57] Su vale ha sido Rechazado por falta de stock</h3>\r\n    <p><strong>Comentarios añadidos:</strong> no hay stock, carga de nuevo en una semana.\n</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 02/06/2018 09:21:44</p>\r\n  <p>eeeee</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:20:22', '[Sistema de Vales #57] Su vale ha sido Rechazado por falta de stock');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('50', 'admin@admin.com', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #30] Su vale ha sido retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> gracias.\n</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 01/29/2018 17:29:41</p>\r\n  <p>eeeee</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:22:19', '[Sistema de Vales #30] Su vale ha sido retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('51', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #35] Su vale ha sido retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> grs</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 01/30/2018 09:40:08</p>\r\n  <p>eeeee</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:23:24', '[Sistema de Vales #35] Su vale ha sido retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('52', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #49] Su vale ha sido Rechazado por falta de stock</h3>\r\n    <p><strong>Comentarios añadidos:</strong> no hay stock papu</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 05/02/2018 13:39:40</p>\r\n  <p>Por Cualquier inconveniente comuniquese con pañol</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:43:57', '[Sistema de Vales #49] Su vale ha sido Rechazado por falta de stock');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('42', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Su Vale ha sido Aprobado</h3>\r\n    <p>Comentarios: todo ok.</p><br>\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n      <p>Una vez que este listo para ser retirado recibirá una notificación indicando esto.\r\n    </p>\r\n    \r\n\r\n</html>\r\n', 'sent', '2018-03-15 15:55:38', '[Sistema de Vales #135] Su vale ha sido Aprobado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('43', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Su Vale ha sido Aprobado</h3>\r\n    <p>Comentarios: </p><br>\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n      <p>Una vez que este listo para ser retirado recibirá una notificación indicando esto.\r\n    </p>\r\n    \r\n\r\n</html>\r\n', 'sent', '2018-03-15 15:55:43', '[Sistema de Vales #134] Su vale ha sido Aprobado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('44', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Su Vale ha sido Aprobado</h3>\r\n    <p>Comentarios: </p><br>\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n      <p>Una vez que este listo para ser retirado recibirá una notificación indicando esto.\r\n    </p>\r\n    \r\n\r\n</html>\r\n', 'sent', '2018-03-15 15:55:48', '[Sistema de Vales #68] Su vale ha sido Aprobado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('45', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #135] Su vale ya esta listo para ser retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> hola que tal</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 03/15/2018 15:46:31</p>\r\n  <p>Su vale de consumo puede ser pasado a retirar por Pañol. <br> <strong>Detalle de Articulos a Entregar</strong><table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Código Articulo</th>\r\n                  <th>Descripción 1</th>\r\n                  <th>Cantidad Solicitada</th>\r\n                  <th>Cantidad a Entregar</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                \r\n                    <tr>\r\n                       <th>5</th>\r\n                       <th>Articulo de Prueba 5</th>\r\n                       <th>4</th>\r\n                       <th>4</th>\r\n                    <tr>\r\n                    <tr>\r\n                       <th>2</th>\r\n                       <th>Item de Prueba 2</th>\r\n                       <th>2</th>\r\n                       <th>2</th>\r\n                    <tr>\r\n                    <tr>\r\n                       <th>7</th>\r\n                       <th>Articulo de Prueba 7</th>\r\n                       <th>44</th>\r\n                       <th>40</th>\r\n                    <tr></tbody>\r\n                                </table></p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 15:57:19', '[Sistema de Vales #135] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('46', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #135] Su vale ya esta listo para ser retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> hola que tal</p>\r\n    <p><strong>Responsable:</strong>Lucas a, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 03/15/2018 15:46:31</p>\r\n  <p>Su vale de consumo puede ser pasado a retirar por Pañol. <br> <strong>Detalle de Articulos a Entregar</strong><table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Código Articulo</th>\r\n                  <th>Descripción 1</th>\r\n                  <th>Cantidad Solicitada</th>\r\n                  <th>Cantidad a Entregar</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                \r\n                    <tr>\r\n                       <th>5</th>\r\n                       <th>Articulo de Prueba 5</th>\r\n                       <th>4</th>\r\n                       <th>4</th>\r\n                    <tr>\r\n                    <tr>\r\n                       <th>2</th>\r\n                       <th>Item de Prueba 2</th>\r\n                       <th>2</th>\r\n                       <th>2</th>\r\n                    <tr>\r\n                    <tr>\r\n                       <th>7</th>\r\n                       <th>Articulo de Prueba 7</th>\r\n                       <th>44</th>\r\n                       <th>40</th>\r\n                    <tr></tbody>\r\n                                </table></p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-15 16:12:11', '[Sistema de Vales #135] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('38', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #30] Su vale ya esta listo para ser retirado</h3>\r\n    <p>Comentarios: hola que tal</p><br>\r\n\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n  <p></p>\r\n\r\n\r\n</html>\r\n', 'sent', '2018-03-15 10:48:26', '[Sistema de Vales #30] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('39', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #135. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas a</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>5</th>\r\n                   <th> Articulo de Prueba 5 </th>\r\n                   <th>4</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>2</th>\r\n                   <th> Item de Prueba 2 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>7</th>\r\n                   <th> Articulo de Prueba 7 </th>\r\n                   <th>44</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/135\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-15 15:46:42', '[Sistema de Vales #135]Nuevo Vale de Consumo #135');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('40', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas a</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>5</th>\r\n                   <th> Articulo de Prueba 5 </th>\r\n                   <th>4</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>2</th>\r\n                   <th> Item de Prueba 2 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>7</th>\r\n                   <th> Articulo de Prueba 7 </th>\r\n                   <th>44</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/135\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/135\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/135\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-15 15:46:47', 'Nuevo Vale para Aprobar. #135');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('41', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Su Vale ha sido Aprobado</h3>\r\n    <p>Comentarios: todo ok.</p><br>\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n      <p>Una vez que este listo para ser retirado recibirá una notificación indicando esto.\r\n    </p>\r\n    \r\n\r\n</html>\r\n', 'sent', '2018-03-15 15:52:10', '[Sistema de Vales #67] Su vale ha sido Aprobado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('37', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\r\n		<h3>[Sistema de Vales #30] Su vale ya esta listo para ser retirado</h3>\r\n    <p>Comentarios: hola que tal</p><br>\r\n\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n  <p></p>\r\n\r\n\r\n</html>\r\n', 'sent', '2018-03-15 10:46:44', '[Sistema de Vales #30] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('36', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 24</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 24<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 24</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 24<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 41</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 41<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 41</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 41<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined property: stdClass::$id_item</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 38</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 38<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 41</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 41<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Warning</p>\n<p>Message:  A non-numeric value encountered</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 44</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 44<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 129<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 482<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\r\n		<h3>[Sistema de Vales #30] Su vale ya esta listo para ser retirado</h3>\r\n    <p>Comentarios: hola que tal</p><br>\r\n\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n  <p></p>\r\n\r\n\r\n</html>\r\n', 'sent', '2018-03-15 10:43:26', '[Sistema de Vales #30] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('35', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Object of class stdClass could not be converted to int</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 15</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 15<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Object of class stdClass could not be converted to int</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 19</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 19<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Object of class stdClass could not be converted to int</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 23</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 23<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Object of class stdClass could not be converted to int</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 27</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 27<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\r\n		<h3>\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined variable: inicio</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 34</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 34<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div></h3>\r\n    <p>Comentarios: hola que tal</p><br>\r\n\r\n    <p>Responsable:Lucas a, Fradusco</p><br>\r\n\r\n  </body><br>\r\n  \n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\n\n<h4>A PHP Error was encountered</h4>\n\n<p>Severity: Notice</p>\n<p>Message:  Undefined variable: id_estado_aprobacion</p>\n<p>Filename: email/update_status.php</p>\n<p>Line Number: 40</p>\n\n\n	<p>Backtrace:</p>\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\update_status.php<br />\n			Line: 40<br />\n			Function: _error_handler			</p>\n\n		\n	\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\n			Line: 133<br />\n			Function: view			</p>\n\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\n			Line: 476<br />\n			Function: Notify_owner_ready			</p>\n\n		\n	\n		\n	\n		\n			<p style=\"margin-left:10px\">\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\n			Line: 315<br />\n			Function: require_once			</p>\n\n		\n	\n\n</div>\r\n\r\n</html>\r\n', 'sent', '2018-03-15 10:08:06', '[Sistema de Vales #30] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('54', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #137. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>401</th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>805</th>\r\n                   <th> ARCILLA LILIANA </th>\r\n                   <th>5</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/137\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-21 10:22:32', '[Sistema de Vales #137]Nuevo Vale de Consumo #137');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('55', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>401</th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                              <tr>\r\n                   <th>805</th>\r\n                   <th> ARCILLA LILIANA </th>\r\n                   <th>5</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/137\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/137\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/137\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-21 10:22:35', 'Nuevo Vale para Aprobar. #137');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('56', 'frivarola@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #138. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Rivarola, Fernando</p><br>\r\n    <p>Sector Aprobador:SELECCIÓN</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>402</th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/138\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-21 10:54:05', '[Sistema de Vales #138]Nuevo Vale de Consumo #138');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('57', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Rivarola, Fernando</p><br>\r\n    <p>Sector Aprobador:SELECCIÓN</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>402</th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/138\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/138\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/138\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-21 10:54:07', '[Sistema de Vales #138] Nuevo Vale para Aprobar. #138');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('58', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #139. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>\r\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\r\n\r\n<h4>A PHP Error was encountered</h4>\r\n\r\n<p>Severity: Notice</p>\r\n<p>Message:  Undefined index: num_articulo</p>\r\n<p>Filename: email/new.php</p>\r\n<p>Line Number: 36</p>\r\n\r\n\r\n	<p>Backtrace:</p>\r\n	\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\new.php<br />\r\n			Line: 36<br />\r\n			Function: _error_handler			</p>\r\n\r\n		\r\n	\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\r\n			Line: 80<br />\r\n			Function: view			</p>\r\n\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\r\n			Line: 476<br />\r\n			Function: Notify_owner			</p>\r\n\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\r\n			Line: 315<br />\r\n			Function: require_once			</p>\r\n\r\n		\r\n	\r\n\r\n</div></th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/139\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-21 15:39:02', '[Sistema de Vales #139]Nuevo Vale de Consumo #139');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('59', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>\r\n<div style=\"border:1px solid #990000;padding-left:20px;margin:0 0 10px 0;\">\r\n\r\n<h4>A PHP Error was encountered</h4>\r\n\r\n<p>Severity: Notice</p>\r\n<p>Message:  Undefined index: num_articulo</p>\r\n<p>Filename: email/new_aprove.php</p>\r\n<p>Line Number: 34</p>\r\n\r\n\r\n	<p>Backtrace:</p>\r\n	\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\views\\email\\new_aprove.php<br />\r\n			Line: 34<br />\r\n			Function: _error_handler			</p>\r\n\r\n		\r\n	\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\libraries\\generales.php<br />\r\n			Line: 146<br />\r\n			Function: view			</p>\r\n\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\application\\controllers\\Vales_consumo.php<br />\r\n			Line: 483<br />\r\n			Function: Notify_responsible			</p>\r\n\r\n		\r\n	\r\n		\r\n	\r\n		\r\n			<p style=\"margin-left:10px\">\r\n			File: C:\\xampp\\htdocs\\Vales\\index.php<br />\r\n			Line: 315<br />\r\n			Function: require_once			</p>\r\n\r\n		\r\n	\r\n\r\n</div></th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/139\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/139\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/139\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-21 15:39:05', '[Sistema de Vales #139] Nuevo Vale para Aprobar. #139');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('60', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #142. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500712 </th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/142\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-21 16:19:03', '[Sistema de Vales #142]Nuevo Vale de Consumo #142');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('61', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500712 </th>\r\n                   <th> RODAMIENTO A RODILLOS 32011 </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/142\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/142\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/142\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-21 16:19:06', '[Sistema de Vales #142] Nuevo Vale para Aprobar. #142');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('62', 'frivarola@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #143. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Rivarola, Fernando</p><br>\r\n    <p>Sector Aprobador:ESMALTERIA</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500713 </th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/143\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-21 16:49:02', '[Sistema de Vales #143]Nuevo Vale de Consumo #143');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('63', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Rivarola, Fernando</p><br>\r\n    <p>Sector Aprobador:ESMALTERIA</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500713 </th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>2</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/143\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/143\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/143\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-21 16:49:05', '[Sistema de Vales #143] Nuevo Vale para Aprobar. #143');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('64', 'panol@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #144. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Alegre, Miguel</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500713 </th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/144\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-22 11:09:02', '[Sistema de Vales #144]Nuevo Vale de Consumo #144');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('65', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Alegre, Miguel</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500713 </th>\r\n                   <th> RODAMIENTO 6022 Z </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/144\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/144\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/144\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-22 11:09:07', '[Sistema de Vales #144] Nuevo Vale para Aprobar. #144');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('66', 'panol@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #145. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Alegre, Miguel</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500715 </th>\r\n                   <th> RODAMIENTO A RODILLOS 7013ACP6 </th>\r\n                   <th>222</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/145\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-22 11:09:10', '[Sistema de Vales #145]Nuevo Vale de Consumo #145');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('67', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Alegre, Miguel</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500715 </th>\r\n                   <th> RODAMIENTO A RODILLOS 7013ACP6 </th>\r\n                   <th>222</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/145\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/145\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/145\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-22 11:09:12', '[Sistema de Vales #145] Nuevo Vale para Aprobar. #145');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('68', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #146. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>26100678 </th>\r\n                   <th> BROCHE DORADO DE 2 PUNTAS TAMA </th>\r\n                   <th>1</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/146\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-22 11:19:02', '[Sistema de Vales #146]Nuevo Vale de Consumo #146');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('69', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>26100678 </th>\r\n                   <th> BROCHE DORADO DE 2 PUNTAS TAMA </th>\r\n                   <th>1</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/146\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/146\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/146\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-22 11:19:05', '[Sistema de Vales #146] Nuevo Vale para Aprobar. #146');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('70', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #147. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>10100111 </th>\r\n                   <th> CAJA KRAF IMPR 30x30 BAM ILVA </th>\r\n                   <th>22222</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/147\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-22 11:19:08', '[Sistema de Vales #147]Nuevo Vale de Consumo #147');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('71', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>10100111 </th>\r\n                   <th> CAJA KRAF IMPR 30x30 BAM ILVA </th>\r\n                   <th>22222</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/147\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/147\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/147\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-22 11:19:11', '[Sistema de Vales #147] Nuevo Vale para Aprobar. #147');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('72', 'panol@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th, tr {\r\n          border: 1px solid black;\r\n          border-collapse: collapse;\r\n      }\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Su Vale ha sido Aprobado</h3>\r\n    <p>Comentarios: </p><br>\r\n    <p>Responsable:Lucas, Fradusco</p><br>\r\n\r\n  </body><br>\r\n      <p>Una vez que este listo para ser retirado recibirá una notificación indicando esto.\r\n    </p>\r\n    \r\n\r\n</html>\r\n', 'sent', '2018-03-22 14:34:02', '[Sistema de Vales #145] Su vale ha sido Aprobado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('73', 'panol@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #145] Su vale ya esta listo para ser retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> </p>\r\n    <p><strong>Responsable:</strong>Lucas, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 22/03/2018 11:07:31</p>\r\n  <p>Su vale de consumo puede ser pasado a retirar por Pañol. <br> <strong>Detalle de Articulos a Entregar</strong><table>\r\n              <thead>\r\n                <tr>\r\n                  <th>Código Articulo</th>\r\n                  <th>Descripción 1</th>\r\n                  <th>Cantidad Solicitada</th>\r\n                  <th>Cantidad a Entregar</th>\r\n                </tr>\r\n              </thead>\r\n              <tbody>\r\n                \r\n                    <tr>\r\n                       <th>412</th>\r\n                       <th>RODAMIENTO A RODILLOS 7013ACP6</th>\r\n                       <th>222</th>\r\n                       <th>0</th>\r\n                    <tr></tbody>\r\n                                </table></p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-22 14:34:05', '[Sistema de Vales #145] Su vale ya esta listo para ser retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('74', 'panol@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #145] Su vale ha sido retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> gracias.\n</p>\r\n    <p><strong>Responsable:</strong>Lucas, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 22/03/2018 11:07:31</p>\r\n  <p>Por Cualquier inconveniente comuniquese con pañol</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-22 14:34:08', '[Sistema de Vales #145] Su vale ha sido retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('75', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n    \r\n		<h3>[Sistema de Vales #53] Su vale ha sido retirado</h3>\r\n    <p><strong>Comentarios añadidos:</strong> </p>\r\n    <p><strong>Responsable:</strong>Lucas, Fradusco</p>\r\n    <p><strong>Fecha de Creación:</strong> 05/02/2018 14:46:21</p>\r\n  <p>Por Cualquier inconveniente comuniquese con pañol</p>\r\n\r\n</body>\r\n</html>\r\n', 'sent', '2018-03-22 15:34:02', '[Sistema de Vales #53] Su vale ha sido retirado');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('76', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #148. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500715 </th>\r\n                   <th> RODAMIENTO A RODILLOS 7013ACP6 </th>\r\n                   <th>333</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/148\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-22 16:24:01', '[Sistema de Vales #148]Nuevo Vale de Consumo #148');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('77', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22500715 </th>\r\n                   <th> RODAMIENTO A RODILLOS 7013ACP6 </th>\r\n                   <th>333</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/148\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/148\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/148\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-22 16:24:04', '[Sistema de Vales #148] Nuevo Vale para Aprobar. #148');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('78', 'lfradusco@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n    <link href=\"http://getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\" />\r\n  </head>\r\n  <body>\r\n		<h3>Vale de consumo creado satisfactoriamente.</h3>\r\n		<p>Se ha creado correctamente el vale de consumo numero #149. El mismo debe ser aprobado por el responsable del sector para que pueda ser preparado.</p><br>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>501000075 </th>\r\n                   <th> ANILINA RODAMINA B ROSA </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/149\"> ACA </a>\r\n</html>\r\n', 'sent', '2018-03-26 10:24:03', '[Sistema de Vales #149]Nuevo Vale de Consumo #149');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('79', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>501000075 </th>\r\n                   <th> ANILINA RODAMINA B ROSA </th>\r\n                   <th>22</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/149\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/149\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/149\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-26 10:24:06', '[Sistema de Vales #149] Nuevo Vale para Aprobar. #149');
INSERT INTO `email_queue` (`id`, `to`, `cc`, `bcc`, `message`, `status`, `date`, `headers`) VALUES ('80', 'rvarios@ilva.com.ar', NULL, NULL, '<!doctype html>\r\n<html>\r\n  <head>\r\n    <meta charset=\"UTF-8\">\r\n    <style>\r\n      th {\r\n\r\n          border: 1px solid black;\r\n          height: 40px;\r\n          border-collapse: collapse;\r\n          vertical-align: bottom;\r\n          padding: 15px;\r\n          text-align: left;\r\n\r\n      }\r\n      tr:hover {background-color: #f5f5f5;}\r\n</style>\r\n  </head>\r\n  <body>\r\n		<h3>Hay un nuevo vale aguardando aprobación.</h3>\r\n    <p>Requeridor: Fradusco, Lucas</p><br>\r\n    <p>Sector Aprobador:MOLINO DISCONTINUO</p><br>\r\n      <table>\r\n          <tread>\r\n            <tr>\r\n              <th>Código Articulo</th>\r\n              <th>Descripción 1</th>\r\n              <th>Cantidad Solicitada</th>\r\n            </tr>\r\n          </tread>\r\n          <tbody>\r\n                            <tr>\r\n                   <th>22222225 </th>\r\n                   <th> articulo de prueba </th>\r\n                   <th>12</th>\r\n                <tr>\r\n                        </tbody>\r\n      </table>\r\n  </body><br>\r\n  Puede realizar un seguimiento del mismo <a href=\"http://localhost/Vales/vales_consumo/view/1\"> ACA </a>\r\n  <br>\r\n  Acciones Rápidas:\r\n <a href=\"http://localhost/Vales/vales_consumo/view/1\"> Aprobar</a>|<a href=\"http://localhost/Vales/vales_consumo/view/1\"> Rechazar</a>\r\n</html>\r\n', 'sent', '2018-03-27 14:44:02', '[Sistema de Vales #1] Nuevo Vale para Aprobar. #1');


#
# TABLE STRUCTURE FOR: estado_aprobacion
#

DROP TABLE IF EXISTS `estado_aprobacion`;

CREATE TABLE `estado_aprobacion` (
  `id_estado_aprobacion_fk` int(11) NOT NULL,
  `nombre_estado_aprobacion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `estado_aprobacion` (`id_estado_aprobacion_fk`, `nombre_estado_aprobacion`) VALUES ('1', 'Pendiente');
INSERT INTO `estado_aprobacion` (`id_estado_aprobacion_fk`, `nombre_estado_aprobacion`) VALUES ('2', 'Aprobado');
INSERT INTO `estado_aprobacion` (`id_estado_aprobacion_fk`, `nombre_estado_aprobacion`) VALUES ('3', 'Rechazado');


#
# TABLE STRUCTURE FOR: estado_entrega
#

DROP TABLE IF EXISTS `estado_entrega`;

CREATE TABLE `estado_entrega` (
  `id_estado_entrega` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_estado` text NOT NULL,
  PRIMARY KEY (`id_estado_entrega`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('1', 'En Proceso De Carga');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('2', 'Pendiente De Aprobacion');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('3', 'En Proceso De Armado');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('4', 'Listo Para Retirar');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('5', 'Retirado');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('6', 'Rechazado por falta de Stock');
INSERT INTO `estado_entrega` (`id_estado_entrega`, `nombre_estado`) VALUES ('9', 'Deshabilitado');


#
# TABLE STRUCTURE FOR: evolucion_aprobacion
#

DROP TABLE IF EXISTS `evolucion_aprobacion`;

CREATE TABLE `evolucion_aprobacion` (
  `id_vale_aprobacion` int(11) NOT NULL,
  `id_estado_aprobacion` int(11) NOT NULL,
  `fecha_aprobacion` int(11) NOT NULL,
  `id_responsable_aprobacion` int(11) NOT NULL,
  `comentarios_aprobacion` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `evolucion_aprobacion` (`id_vale_aprobacion`, `id_estado_aprobacion`, `fecha_aprobacion`, `id_responsable_aprobacion`, `comentarios_aprobacion`) VALUES ('1', '1', '1522172616', '2', '');
INSERT INTO `evolucion_aprobacion` (`id_vale_aprobacion`, `id_estado_aprobacion`, `fecha_aprobacion`, `id_responsable_aprobacion`, `comentarios_aprobacion`) VALUES ('1', '2', '1522173237', '2', '');


#
# TABLE STRUCTURE FOR: evolucion_vale
#

DROP TABLE IF EXISTS `evolucion_vale`;

CREATE TABLE `evolucion_vale` (
  `id_vale_evolucion` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `fecha` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL,
  `observacion` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `evolucion_vale` (`id_vale_evolucion`, `id_estado`, `fecha`, `id_responsable`, `observacion`) VALUES ('1', '2', '1522172616', '2', '');
INSERT INTO `evolucion_vale` (`id_vale_evolucion`, `id_estado`, `fecha`, `id_responsable`, `observacion`) VALUES ('1', '3', '1522173237', '2', '');


#
# TABLE STRUCTURE FOR: fk_categorias
#

DROP TABLE IF EXISTS `fk_categorias`;

CREATE TABLE `fk_categorias` (
  `id_fk_categoria` int(11) NOT NULL AUTO_INCREMENT,
  `codigo_categoria` enum('Familia','Cod1','Cod2','Cod3') NOT NULL,
  `nombre_categoria` varchar(6) NOT NULL,
  `descripcion_categoria` varchar(25) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_fk_categoria`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;

INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('1', 'Familia', 'ALU', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('2', 'Familia', 'ARC', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('3', 'Familia', 'FEL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('4', 'Familia', 'ICO', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('5', 'Familia', 'IME', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('6', 'Familia', 'IPU', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('7', 'Familia', 'ISE', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('8', 'Familia', 'MES', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('9', 'Familia', 'MPR', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('10', 'Familia', 'NAA', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('11', 'Familia', 'REP', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('12', 'Cod1', 'CAJ', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('13', 'Cod1', 'ETI', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('14', 'Cod1', 'FER', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('15', 'Cod1', 'FLJ', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('16', 'Cod1', 'FLO', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('17', 'Cod1', 'LAB', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('18', 'Cod1', 'LIB', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('19', 'Cod1', 'LIM', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('20', 'Cod1', 'MEC', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('21', 'Cod1', 'MPR', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('22', 'Cod1', 'NAA', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('23', 'Cod1', 'NEU', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('24', 'Cod1', 'PLL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('25', 'Cod1', 'TER', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('26', 'Cod2', 'ACC', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('27', 'Cod2', 'ADI', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('28', 'Cod2', 'BAN', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('29', 'Cod2', 'BOL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('30', 'Cod2', 'BSE', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('31', 'Cod2', 'CBZ', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('32', 'Cod2', 'CEA', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('33', 'Cod2', 'CEP', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('34', 'Cod2', 'CIL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('35', 'Cod2', 'CIN', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('36', 'Cod2', 'CRR', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('37', 'Cod2', 'CRT', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('38', 'Cod2', 'DET', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('39', 'Cod2', 'DIS', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('40', 'Cod2', 'EJE', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('41', 'Cod2', 'ETI', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('42', 'Cod2', 'FLO', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('43', 'Cod2', 'MOL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('44', 'Cod2', 'NAA', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('45', 'Cod2', 'PEG', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('46', 'Cod2', 'RET', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('47', 'Cod2', 'RUL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('48', 'Cod2', 'SAT', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('49', 'Cod2', 'TIN', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('50', 'Cod2', 'TON', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('51', 'Cod2', 'VEL', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('52', 'Cod3', 'ICO', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('53', 'Cod3', 'IME', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('54', 'Cod3', 'IMO', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('55', 'Cod3', 'IPU', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('56', 'Cod3', 'ISE', 'Descripcion Categoria', '1');
INSERT INTO `fk_categorias` (`id_fk_categoria`, `codigo_categoria`, `nombre_categoria`, `descripcion_categoria`, `status`) VALUES ('57', 'Cod3', 'NAA', 'Descripcion Categoria', '1');


#
# TABLE STRUCTURE FOR: fk_motivo
#

DROP TABLE IF EXISTS `fk_motivo`;

CREATE TABLE `fk_motivo` (
  `id_motivo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_motivo` text NOT NULL,
  `cod_jde` varchar(3) NOT NULL,
  `descripcion` text NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id_motivo`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('0', 'S/M', '0', 'Vale de M.Prima', '0');
INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('1', 'Parada de Planta ', 'I8', 'Vale de consumo (Parada)	', '1');
INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('2', 'Proyectos Modificaciones ', 'I5', 'Vale de consumo (Capex)', '1');
INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('3', 'Preventivo/Programado', 'I9', 'Vale de Consumo (Pañol)', '1');
INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('4', 'Correctivo/Urgente /Rotura', 'I9', 'Vale de Consumo (Pañol)', '1');
INSERT INTO `fk_motivo` (`id_motivo`, `nombre_motivo`, `cod_jde`, `descripcion`, `status`) VALUES ('5', 'Montaje', 'I9', 'Vale de Consumo (Pañol)', '1');


#
# TABLE STRUCTURE FOR: fk_un_med
#

DROP TABLE IF EXISTS `fk_un_med`;

CREATE TABLE `fk_un_med` (
  `id_un_medida` int(11) NOT NULL AUTO_INCREMENT,
  `un_medida` varchar(12) NOT NULL,
  `nombre_un_medida` text NOT NULL,
  PRIMARY KEY (`id_un_medida`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=latin1;

INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('1', '%', 'Porcentaje');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('2', 'AC', 'Acre');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('3', 'AS', 'Sal anual (redondeado)xmult');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('4', 'AT', 'Salario anual (truncado)x mult');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('5', 'B1', 'Balde de 10 Litros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('6', 'BA', 'Barra absoluta (Presión)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('7', 'BC', 'Bolsa');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('8', 'BD', 'Bidon');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('9', 'BG', 'Barra medición (Presión)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('10', 'BK', 'Balde');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('11', 'BL', 'Barriles');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('12', 'BO', 'BLOCK');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('13', 'BR', 'Barra');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('14', 'BT', 'Botellas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('15', 'BU', 'Bushel (36.36 litros)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('16', 'BX', 'Caja');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('17', 'C2', 'Centimetros Cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('18', 'C3', 'Centimetros Cúbicos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('19', 'CA', 'Cajón');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('20', 'CC', 'Centimetro cúbico');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('21', 'CF', 'Cien pies');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('22', 'CI', 'Pulgadas cúbicas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('23', 'CJ', 'Caja');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('24', 'CL', 'Centilitros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('25', 'CM', 'Centímetros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('26', 'CN', 'Lata');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('27', 'CR', 'Caja cartón');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('28', 'CS', 'Cien pies cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('29', 'CT', 'Quilate');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('30', 'CV', 'Cajas Crossbille');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('31', 'CW', 'Quintal');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('32', 'CY', 'Yardas cúbicas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('33', 'D2', 'Decímetros Cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('34', 'D3', 'Decimetro Cubico');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('35', 'DC', 'Decímetros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('36', 'DL', 'Decilitro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('37', 'DR', 'Tambor');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('38', 'DW', 'Escrúpulo');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('39', 'DY', 'Dias');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('40', 'DZ', 'Docena');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('41', 'EA', 'Unidad');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('42', 'FC', 'Pies cúbicos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('43', 'FF', 'Pies/Pulgadas/16º');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('44', 'FO', 'Onza líquida');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('45', 'FT', 'Pies');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('46', 'G1', '100 Galones');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('47', 'GA', 'Galones');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('48', 'GM', 'Gramos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('49', 'GP', 'Galón puro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('50', 'GR', 'Bruto');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('51', 'H1', 'Cálculos de media hora');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('52', 'HA', 'Tarifa promedio por hora');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('53', 'HE', 'Recuento');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('54', 'HH', 'Horas x Horas trabajadas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('55', 'HL', 'Hectólitro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('56', 'HQ', 'Horas por periodo (cero $)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('57', 'HR', 'Hora');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('58', 'HT', 'Hectárea');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('59', 'HZ', 'Hrs x Hrs trabajadas (cero $)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('60', 'IC', 'Pulgadas cúbicas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('61', 'IG', 'Galón inglés');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('62', 'IN', 'Pulgadas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('63', 'JT', 'Juntas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('64', 'KG', 'Kilogramo');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('65', 'KI', 'Kit');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('66', 'KL', 'Kilolitro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('67', 'KM', 'Kilómetro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('68', 'KN', 'Kilogramo Neto');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('69', 'KT', 'Quilate');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('70', 'L3', 'Libras por pulgada cuadrada');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('71', 'LA', 'Lata');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('72', 'LB', 'Libras');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('73', 'LC', 'Litros cúbicos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('74', 'LF', 'Pies lineales');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('75', 'LG', 'Troncos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('76', 'LP', 'Litros de eficacia');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('77', 'LS', 'Suma global');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('78', 'LT', 'Litros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('79', 'M2', 'Metros cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('80', 'M3', 'Metros cúbicos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('81', 'MF', 'Mil pies');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('82', 'MG', 'Miligramos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('83', 'MH', 'Horas hombre');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('84', 'MI', 'Millas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('85', 'MK', 'Microgramos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('86', 'ML', 'Mililitro');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('87', 'MM', 'Milímetros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('88', 'MN', 'Minutos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('89', 'MO', 'Meses');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('90', 'MP', 'Mil piezas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('91', 'MS', 'Mil pies cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('92', 'MT', 'Metros');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('93', 'MV', 'Metros 2 Crossville');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('94', 'MW', 'Mil libras');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('95', 'OP', 'Onzas puras');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('96', 'OT', 'Onza troy');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('97', 'OZ', 'Onzas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('98', 'PA', 'Plancha');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('99', 'PC', 'Piezas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('100', 'PD', 'Cojín');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('101', 'PL', 'Tarima');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('102', 'PR', 'Par');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('103', 'PT', 'Pinta');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('104', 'PV', 'Pallets Corssbille');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('105', 'PZ', 'Piezas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('106', 'QT', 'Cuarto de galón');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('107', 'RD', 'Depósito alquiler');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('108', 'RL', 'Rollo');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('109', 'RM', 'Resma');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('110', 'RT', '$1000s del salario');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('111', 'SE', 'Segundos');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('112', 'SF', 'Pies cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('113', 'SI', 'Pulgadas cuadradas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('114', 'SK', 'Madeja');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('115', 'SL', 'Manga');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('116', 'SM', 'Metros cuadrados');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('117', 'SP', 'Espacios');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('118', 'SX', 'Paquete de seis');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('119', 'SY', 'Yarda cuadrada');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('120', 'TI', 'Tira');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('121', 'TK', 'Tanque');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('122', 'TL', 'Tonelada larga (Inglés)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('123', 'TM', 'Tonelada métrica');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('124', 'TN', 'Tonelada (EEUU)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('125', 'TS', 'Tonelada corta (EEUU)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('126', 'UN', 'Unidades');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('127', 'WK', 'Semanas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('128', 'WU', 'Unidades soldadura');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('129', 'XL', 'Exceso vida');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('130', 'YD', 'Yardas');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('131', 'YR', 'Año');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('132', 'Z', 'Configuración (3-PW)');
INSERT INTO `fk_un_med` (`id_un_medida`, `un_medida`, `nombre_un_medida`) VALUES ('133', 'SUN', 'Sin UN de med');


#
# TABLE STRUCTURE FOR: groups
#

DROP TABLE IF EXISTS `groups`;

CREATE TABLE `groups` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('1', 'admin', 'Administrator');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('2', 'Requeridor', 'Requeridor');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('3', 'Aprobador', 'Aprobador');
INSERT INTO `groups` (`id`, `name`, `description`) VALUES ('4', 'Pañolero', 'Pañolero');


#
# TABLE STRUCTURE FOR: jerarquias
#

DROP TABLE IF EXISTS `jerarquias`;

CREATE TABLE `jerarquias` (
  `id_jerarquia` int(11) NOT NULL AUTO_INCREMENT,
  `id_user_padre` int(11) NOT NULL,
  `id_user_hijo` int(11) NOT NULL,
  `id_sector_jerarquia` int(11) NOT NULL,
  PRIMARY KEY (`id_jerarquia`),
  KEY `id_sector_jerarquia` (`id_sector_jerarquia`),
  CONSTRAINT `jerarquias_ibfk_1` FOREIGN KEY (`id_sector_jerarquia`) REFERENCES `sector_req` (`id_sector_req`)
) ENGINE=InnoDB AUTO_INCREMENT=500 DEFAULT CHARSET=latin1;

INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('6', '2', '2', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('7', '2', '2', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('8', '2', '2', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('9', '2', '2', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('10', '2', '2', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('334', '2', '2', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('347', '2', '2', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('348', '2', '2', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('349', '3', '3', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('352', '3', '3', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('353', '3', '3', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('354', '3', '3', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('356', '4', '4', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('357', '4', '4', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('358', '4', '4', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('359', '4', '4', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('360', '4', '4', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('361', '5', '5', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('362', '5', '5', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('363', '5', '5', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('364', '6', '6', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('365', '6', '6', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('373', '1', '1', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('375', '1', '1', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('376', '1', '1', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('377', '1', '1', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('378', '1', '1', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('379', '1', '1', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('380', '8', '8', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('381', '8', '8', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('382', '8', '8', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('383', '8', '8', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('384', '8', '8', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('385', '8', '8', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('386', '8', '8', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('387', '8', '8', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('388', '8', '8', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('389', '8', '8', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('390', '8', '8', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('391', '8', '8', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('392', '8', '8', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('393', '8', '8', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('394', '8', '8', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('395', '8', '8', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('396', '8', '8', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('397', '8', '8', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('398', '8', '8', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('399', '8', '8', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('400', '9', '9', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('401', '9', '9', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('402', '9', '9', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('403', '9', '9', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('404', '9', '9', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('405', '9', '9', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('406', '9', '9', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('407', '9', '9', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('408', '9', '9', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('409', '9', '9', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('410', '9', '9', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('411', '9', '9', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('412', '9', '9', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('413', '9', '9', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('414', '9', '9', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('415', '9', '9', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('416', '9', '9', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('417', '9', '9', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('418', '9', '9', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('419', '9', '9', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('420', '10', '10', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('421', '10', '10', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('422', '10', '10', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('423', '10', '10', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('424', '10', '10', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('425', '10', '10', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('426', '10', '10', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('427', '10', '10', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('428', '10', '10', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('429', '10', '10', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('430', '10', '10', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('431', '10', '10', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('432', '10', '10', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('433', '10', '10', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('434', '10', '10', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('435', '10', '10', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('436', '10', '10', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('437', '10', '10', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('438', '10', '10', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('439', '10', '10', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('440', '11', '11', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('441', '11', '11', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('442', '11', '11', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('443', '11', '11', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('444', '11', '11', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('445', '11', '11', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('446', '11', '11', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('447', '11', '11', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('448', '11', '11', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('449', '11', '11', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('450', '11', '11', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('451', '11', '11', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('452', '11', '11', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('453', '11', '11', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('454', '11', '11', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('455', '11', '11', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('456', '11', '11', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('457', '11', '11', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('458', '11', '11', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('459', '11', '11', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('460', '12', '12', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('461', '12', '12', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('462', '12', '12', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('463', '12', '12', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('464', '12', '12', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('465', '12', '12', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('466', '12', '12', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('467', '12', '12', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('468', '12', '12', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('469', '12', '12', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('470', '12', '12', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('471', '12', '12', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('472', '12', '12', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('473', '12', '12', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('474', '12', '12', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('475', '12', '12', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('476', '12', '12', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('477', '12', '12', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('478', '12', '12', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('479', '12', '12', '7');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('480', '13', '13', '26');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('481', '13', '13', '25');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('482', '13', '13', '24');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('483', '13', '13', '23');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('484', '13', '13', '22');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('485', '13', '13', '21');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('486', '13', '13', '20');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('487', '13', '13', '19');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('488', '13', '13', '18');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('489', '13', '13', '17');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('490', '13', '13', '16');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('491', '13', '13', '15');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('492', '13', '13', '14');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('493', '13', '13', '13');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('494', '13', '13', '12');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('495', '13', '13', '11');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('496', '13', '13', '10');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('497', '13', '13', '9');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('498', '13', '13', '8');
INSERT INTO `jerarquias` (`id_jerarquia`, `id_user_padre`, `id_user_hijo`, `id_sector_jerarquia`) VALUES ('499', '13', '13', '7');


#
# TABLE STRUCTURE FOR: login_attempts
#

DROP TABLE IF EXISTS `login_attempts`;

CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

#
# TABLE STRUCTURE FOR: notificaciones_users
#

DROP TABLE IF EXISTS `notificaciones_users`;

CREATE TABLE `notificaciones_users` (
  `id_notificaciones_users` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `vale_nuevo` tinyint(1) NOT NULL,
  `vale_aprobado` tinyint(1) NOT NULL,
  `vale_listo` tinyint(1) NOT NULL,
  `vale_retirado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_notificaciones_users`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('2', '3', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('6', '6', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('7', '1', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('8', '2', '0', '0', '0', '0');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('9', '8', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('11', '9', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('12', '10', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('13', '11', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('14', '12', '1', '1', '1', '1');
INSERT INTO `notificaciones_users` (`id_notificaciones_users`, `user_id`, `vale_nuevo`, `vale_aprobado`, `vale_listo`, `vale_retirado`) VALUES ('15', '13', '1', '1', '1', '1');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_rol` text NOT NULL,
  `descripcion_rol` text NOT NULL,
  `status_roles` int(11) NOT NULL,
  PRIMARY KEY (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('1', 'VerArticulos', 'VerArticulos', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('2', 'AdministrarRoles', 'AdministrarRoles', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('3', 'AdministrarRoles', 'AdministrarRoles', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('4', 'EditarArticulos', 'EditarArticulos', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('5', 'AltaArticulos', 'AltaArticulos', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('6', 'AdministrarUsuarios', 'AdministrarUsuarios', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('7', 'VerArticulos', 'VerArticulos', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('8', 'VerVales', 'VerVales', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('9', 'NuevoVale', 'NuevoVale', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('10', 'VerVale', 'VerVale', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('11', 'AprobarVales', 'AprobarVales', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('12', 'ArmadoDeVales', 'ArmadoDeVales', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('13', 'Aprobar Vales', 'Aprobar Vales', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('14', 'Ver Dashboard', 'Ver Dashboard', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('15', 'Preparar Vale', 'Preparar Vale', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('17', 'Administrar Sectores', 'Permite al usuario hacer ABM de Sectores para ser imputados en los vales de consumo.', '0');
INSERT INTO `roles` (`id_rol`, `nombre_rol`, `descripcion_rol`, `status_roles`) VALUES ('18', 'Administrar Roles Por Usuario', 'Permite al usuario hacer ABM sobre los roles que tiene otro usuario.', '0');


#
# TABLE STRUCTURE FOR: roles_groups
#

DROP TABLE IF EXISTS `roles_groups`;

CREATE TABLE `roles_groups` (
  `id_rol_` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`id_rol_`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `roles_groups_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id_rol`)
) ENGINE=InnoDB AUTO_INCREMENT=135 DEFAULT CHARSET=latin1;

INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('17', '2', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('34', '3', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('35', '3', '2');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('36', '3', '3');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('37', '3', '4');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('38', '3', '5');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('39', '3', '6');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('40', '3', '7');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('41', '3', '8');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('42', '3', '9');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('44', '3', '11');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('45', '3', '12');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('46', '3', '13');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('47', '3', '14');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('48', '3', '15');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('110', '1', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('111', '1', '2');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('112', '1', '3');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('113', '1', '4');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('114', '1', '5');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('115', '1', '6');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('116', '1', '7');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('117', '1', '8');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('118', '1', '9');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('119', '1', '10');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('120', '1', '11');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('121', '1', '12');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('122', '1', '13');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('123', '1', '14');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('124', '1', '15');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('125', '8', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('126', '13', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('127', '8', '15');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('128', '8', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('129', '9', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('130', '10', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('131', '11', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('132', '12', '1');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('133', '2', '12');
INSERT INTO `roles_groups` (`id_rol_`, `user_id`, `role_id`) VALUES ('134', '2', '1');


#
# TABLE STRUCTURE FOR: sector_req
#

DROP TABLE IF EXISTS `sector_req`;

CREATE TABLE `sector_req` (
  `id_sector_req` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_sector` text NOT NULL,
  `FASE` varchar(10) NOT NULL,
  `status_sector` int(11) NOT NULL,
  PRIMARY KEY (`id_sector_req`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;

INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('7', 'MOLINO DISCONTINUO', 'MD ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('8', 'MOLINO CONTINUO', 'MC ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('9', 'PRENSA ', 'PRE ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('10', 'ESMALTERIA', 'ESM ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('11', 'HORNO', 'HOR ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('12', 'MOLINO ESMALTE', 'MES ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('13', 'LAB.TECNICO', 'LTEC ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('14', 'LAB.DESARROLLO', 'LDES ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('15', 'LAB.SERIGRAFICO', 'LSER ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('16', 'PULIDORA', 'PUL ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('17', 'SELECCIÓN', 'SEL ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('18', 'CORTE', 'COR ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('19', 'MANT.ELECTRICO', 'MELE ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('20', 'MANT.MECANICO', 'MMEC ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('21', 'MERCADO .INTERNO (MKT) PANELES', 'MINT ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('22', 'GERRENCIA (TODO ADMINISTRACION)', 'GER ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('23', 'MANT. EDIFICIO ', 'MEDI ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('24', 'LOGISTICA Y PROGRAMACION', 'LYP ', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('25', 'MOLDES Y MATRICERIA ', 'MYM', '1');
INSERT INTO `sector_req` (`id_sector_req`, `nombre_sector`, `FASE`, `status_sector`) VALUES ('26', 'GERRENCIA PRODUCCION', 'GPRO', '1');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(254) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('1', '127.0.0.1', 'administrator', '$2y$08$DpJI3IonwpkwYK2qUpQYFu9xgdosO1JuC9qFkUa//hb8xFXGXx0vK', '', 'admin@admin.com', '', NULL, NULL, NULL, '1268889823', '1521226882', '1', 'Admin', 'Admin', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('2', '::1', 'lfradusco', '$2y$08$31FHIl5cP53eqXAUmD6mQ.kjfec7pwk30jrUJ5X2TE1IOdH2Lzxvi', NULL, 'lfradusco@ilva.com.ar', NULL, NULL, NULL, 'zmpj.Tf77I/bl8ahTj25TO', '1514471610', '1522071992', '1', 'Lucas', 'Fradusco', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('3', '::1', 'rvarios', '$2y$08$.y2equUI8P615lwIjAswh.9QumsXBi36Usqr2fCZxbHptHl1c9UtG', NULL, 'rvarios@ilva.com.ar', NULL, NULL, NULL, NULL, '1514483307', NULL, '1', 'Requeridor', 'Sectores Varios', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('6', '::1', 'resmalteria', '$2y$08$olTzKz3KdLDa8cXK/rBnQuB/8a9bcQmuxyWl.iQH0I3BeDeU3yruu', NULL, 'sistemas@ilva.com.ar', NULL, 'AS1BDg6bVDDbdYZCpPMeZu1adf53a4f700e30f83', '1520423485', NULL, '1514918652', NULL, '1', 'Requeridor', 'Esmalteria', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('8', '::1', 'lamoedo', '$2y$08$Vg6jMmyKxwpHRh7eZUJ7Yuf8fRR6nMTfMfgPoArgktskRjhP70t76', NULL, 'lamoedo@ilva.com.ar', NULL, NULL, NULL, NULL, '1520618472', '1521209163', '1', 'Leandro ', 'Amoedo', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('9', '::1', 'jguevara', '$2y$08$lqtkVvlP366mHANSZ8rfJuv65vEW6wSfREUpWz6U3l/hdmmN7zuoS', NULL, 'panol@ilva.com.ar', NULL, NULL, NULL, NULL, '1521226975', NULL, '1', 'Javier', 'Guevara', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('10', '::1', 'dperez', '$2y$08$FqpXoRB.dnN/FBYtwded0extm2GfBt8w8HZptp7U0.Wn.qgIsNHzi', NULL, 'panol@ilva.com.ar', NULL, NULL, NULL, NULL, '1521227019', NULL, '1', 'Daniel', 'Perez', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('11', '::1', 'malegre', '$2y$08$vejNM.mmfF8kwNpNbyghNOcOjWcUFDbxeI8HbL.9Lnigip2436Nnm', NULL, 'panol@ilva.com.ar', NULL, NULL, NULL, NULL, '1521227094', '1522071735', '1', 'Miguel', 'Alegre', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('12', '::1', 'ecastaño', '$2y$08$gfHYkxNQZkEq8zwd0.5iju8Zz7S41fs6U.DYtzwixZnE/l9pb/F9a', NULL, 'panol@ilva.com.ar', NULL, NULL, NULL, NULL, '1521227336', NULL, '1', 'Esteban', 'Castaño', NULL, NULL);
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES ('13', '::1', 'frivarola', '$2y$08$0Tv77Fx.pu/2Dh/u1RBTBecb9k1CAp15b23.qAeasikwROzgbf6fK', NULL, 'frivarola@ilva.com.ar', NULL, NULL, NULL, '2X6msaLVVMEBmVMprcQv1e', '1521227533', '1522159457', '1', 'Fernando', 'Rivarola', NULL, NULL);


#
# TABLE STRUCTURE FOR: users_groups
#

DROP TABLE IF EXISTS `users_groups`;

CREATE TABLE `users_groups` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  KEY `fk_users_groups_users1_idx` (`user_id`),
  KEY `fk_users_groups_groups1_idx` (`group_id`),
  CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('14', '1', '1');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('5', '2', '1');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('10', '3', '3');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('9', '6', '2');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('22', '8', '4');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('18', '9', '4');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('19', '10', '4');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('20', '11', '4');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('21', '12', '4');
INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES ('23', '13', '1');


#
# TABLE STRUCTURE FOR: vales_consumo
#

DROP TABLE IF EXISTS `vales_consumo`;

CREATE TABLE `vales_consumo` (
  `id_vale` int(11) NOT NULL AUTO_INCREMENT,
  `id_requeridor` int(11) NOT NULL,
  `id_sector` int(11) NOT NULL,
  `id_estado` int(11) NOT NULL,
  `id_aprobacion` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `id_responsable` int(11) NOT NULL,
  `id_motivo` int(11) NOT NULL,
  `fecha_creado` int(11) NOT NULL,
  PRIMARY KEY (`id_vale`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `vales_consumo` (`id_vale`, `id_requeridor`, `id_sector`, `id_estado`, `id_aprobacion`, `id_tipo`, `id_responsable`, `id_motivo`, `fecha_creado`) VALUES ('1', '2', '7', '3', '2', '0', '0', '1', '1522172616');


